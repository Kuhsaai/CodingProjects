class Main {
  public static void main(String[] args) {
    int a = 9;
    int b = 5;
    System.out.println("The variables are first: " + a + " " + b);
    swapped(a,b);
    for (int i = 0; i < 1000; i++) {
      System.out.println("Fact(" + i + ") = " + fact(i));
    }
    
    
  }
   public static int fact(int n) {
    if (n == 0) {
      return 1;
    } else {
      return n * fact(n-1);
    }
  }
  public static int fib(int n) {
    if (n == 0 || n==1) {
      return 1;
    } else {
      return fib(n-1) + fib(n-2);
    }
    
  }
  public static void swapped(int a, int b) {
    int c = a;
    a = b;
    b = c;
    System.out.println("The variables swapped is: " + a + " " + b);
   
  }
}