import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    String userInput;
    
    System.out.println("What vehicle do you use to travel in the winter?");

    userInput = scan.nextLine();

    System.out.println(userInput);

    switch(userInput) {
      case "SUV":
      System.out.println("Thats cool!");
      break;

      case "Sedan":
      System.out.println("That's a horrible car for winter condition");
      break;
      
      case "Convertible":
      System.out.println("That's a horrible car for winter conditions");
      break;

      default:
      System.out.println("So you like " + userInput + " huh, that's an interesting choice");
      break;



    }


  }
}