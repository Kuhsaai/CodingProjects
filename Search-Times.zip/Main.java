/*

Record the time for the following search:

Linear Search:
1:                   48420 Nanoseconds
100:                 48120 Nanoseconds
1,000:               51610 Nanoseconds
10,000:             134190 Nanoseconds
100,000:            534270 Nanoseconds
1,000,000:         8413190 Nanoseconds
1,000,001:        38816769 Nanoseconds

Binary Search:
1:                   74909 Nanoseconds
100:                 44490 Nanoseconds
1,000:               42430 Nanoseconds
10,000:              30960 Nanoseconds
100,000:             17260 Nanoseconds
1,000,000:           22460 Nanoseconds
1,000,001:           55830 Nanoseconds

Write a couple sentences about what you observed:

Linear search took the longest when searching for integers further down the list. 
Binary search, since it kept splitting the range in half after every run, took much less.
Binary search is the faster option unless lets say you have a very long list, and looking for a number at the edges. 

*/
class Main {

public static int linearSearch(int a[], int search) {
  
  for (int i = 0; i < a.length; i++) {
    
    if (search == a[i]) {
      return i;
      }
    }
  
  return -1;
}

public static int binarySearch(int a[], int search) {
  
  int holdVar = (a.length / 2);
  int rangeMin = 0;
  int rangeMax = a.length - 1;
  
 while (rangeMin <= rangeMax) {

   //This returns the index if the search is exactly at the halfway mark
   if (search == a[holdVar]) {
     return holdVar;
   }
   
   if (search < a[holdVar] ) {
    rangeMax = holdVar - 1;
    holdVar = (rangeMin + rangeMax) / 2;
  }

  if (search > a[holdVar]) {
    rangeMin = holdVar + 1;
    holdVar = (rangeMin + rangeMax) / 2;
  }
   
 }
  
  return -1;
}

  
public static void main(String[] args) {
  
  int[] myArray = new int[1000000];
  for (int i = 0; i < myArray.length - 1; i++) {
    myArray[i] = i + 1;
   // System.out.println(i);
    }
  
  long startTime;
  startTime = System.nanoTime();
  
  System.out.println(binarySearch( myArray, 1) + " This took " + (System.nanoTime() - startTime) + " Nanoseconds");
  }
}
