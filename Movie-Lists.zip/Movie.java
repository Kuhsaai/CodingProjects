public class Movie {
public String name;
public int minutes;
public Movie next;
public Movie(String name, int minutes) {
this.name = name;
this.minutes = minutes;
}

  
}
