
class Main {
public static void main(String[] args) {
  MovieList list = new MovieList();
  int mins;

  list.addToFront("Random Movie1", 80);
  list.addToFront("Random Movie2", 120);
  list.addToFront("Random Movie3", 200);
  
  mins = list.sum();

  list.print();
  System.out.println(mins);
  
}
  
}
