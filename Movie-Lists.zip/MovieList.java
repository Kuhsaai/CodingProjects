public class MovieList {
Movie head, tail;
int movMins =0;
public MovieList() {
head = null;
tail = null;
}
public void addToFront(String name, int minutes) {
Movie m = new Movie(name, minutes);
m.next = head;
head = m;
tail = m;
}

  public void addToEnd(String name, int minutes) {
    Movie m = new Movie(name, minutes);
    for (int a = 0; a <count() - 1; a++) {
      if (a == count() - 2) {
        m.next = tail;
      }
      if ( a == count() - 1) {
        m.next = head;
}
    }
  }


public void print() {
  if (head == null) {
    return;
  }

  Movie current = head;

  while (current != null) {
    System.out.println(current.name);
    current = current.next;
  }
}

public int count() {
  if (head == null) {
    return 0;
  }

  int c = 0;

  Movie current = head;
  while(current != null) {
    c++;
    current = current.next;
  }
  return c;
}

  public int sum(Movie m) {
    if (head == null) {
      return 0;
    }
    else {
      return  m.minutes;
    }
  }
  
  public int sum() {
    for (int i = 0; i < count() - 1;) {
      i++;
     movMins = movMins + sum(head);
    }
    return movMins;
  }


  
}