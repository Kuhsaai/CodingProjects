
//The method parse is an online algorithm due to it going line by line rather than taking the code in its entirely and working all at once.
//The runtime would be O(n) due to the runtime per tag being O(1), and the more tags there are. the longer the runtime would be. for N tags, the runtime would be O(n)
class Main {
  public static void main(String[] args) {

  // Makes the String for tests
   String[] testCases = {
        "<html>\nThis is my awesome webpage!\n</html>\n",                   //true
        "<html>\n<body>\n<b>CS241</b> is awesome!\n</html>\n</body>\n",     //false
        "<p><b>Here is some text!</b>",                                     //false
        "<p><b><i>Italics and bold!</i>just bold</b></p>",                  //true
        "<TAG_I_made_up>Professor Carmine!</tag_I_made_up>",                //true
        "<test>hello",                                                      //false
        "hello</test>"                                                      //false
        };

    //Runs the strings made previously
        for (String test : testCases) {
            System.out.println(parse(test));
        }
    
  }

  
  public static boolean parse(String html) {
    //Initializing variables used
    String hold = " ";
    Stack s = new Stack();
    int start = 0;
    boolean hasPushed = false;

    //Making sure every iteration only runs for the length of the inputed string
    while( start < html.length()) {

    //Takes tags starting at < and ending at > and making them sub strings
    int p1 = html.indexOf("<", start);
    int p2 = html.indexOf(">", start);

      // Check if these are < 0
      if (p1 < 0 || p2 < 0) {
        break;
      } 
      
      
    String temp = html.substring(p1, p2); 

  //After every iteration for a tag, starts to check for anotehr tag after the previous one ends
  //  System.out.println(temp);
    start = p2 + 1;

      //If the tag is a starter, pushes it to the stack
    if (!temp.contains("/")) {
        
        s.push(temp);
      hasPushed = true;
        //System.out.println("We have pushed " + temp);
        temp = " ";
      
    } else {
      //If the tag is an ender and matches the top of the stack while it isn't empty, takes out the "/" and pops it.
          temp = temp.replace("/","");

          if (s.isEmpty()) {
            
            break;
            
          } else {
          //System.out.println("We have popped " + temp);
            
          hold = s.pop().data;
            
            }
      // If the tag doesnt line up with the top of the stack it returns false
        if(!hold.equalsIgnoreCase(temp)) {
          
          return false;
          
        }
    }

   
  } // End while loop
    //as long as the string has pushed atleast once and is currently empty, return true since its valid. Otherwise it is invalid and returns false
    if (s.isEmpty() && hasPushed) {
     
      return true;
     
    } else {
     
    return false;
     
    }
   
  }


  
//Im a happy little camper :)


}