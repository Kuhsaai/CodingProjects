import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    /*
Prompt the user to input their top 3 favorite types of shoes
Choices can be Jordans, Adidas, Under Armor, Converse, Dr.Martens, Uggs,  Nikes, or other
If you input any combination of Jordan nikes dr. Martens or Ugg the output will be Excellent choice
If you input any combination including Converse or Adidas then the output is You need to improve your Style
If you input Under armor or other the out put will be You have no style

    */
  Scanner scan = new Scanner(System.in);
  String userInput;


  System.out.println("What are your top 3 favorite types of shoes between Jordans, Adidas, Under Armor, Converse,\n Dr.Martens, Uggs, or Nikes??");

  userInput = scan.nextLine();
  if (userInput.contains("Jordans") || userInput.contains("Nikes") || userInput.contains("Dr. Martens") || userInput.contains("Ugg")) {
    System.out.println("Excellent choice");
  } else {
    if (userInput.contains("Converse") || userInput.contains("Adidas")) {
      System.out.println("You need to imrpove your style");
    } else {
      System.out.println("You have no style");
    }
  }
  }
}