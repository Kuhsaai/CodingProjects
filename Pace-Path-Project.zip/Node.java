import java.util.ArrayList;

public class Node extends Helper implements Comparable<Node> {

  String name;
  int money;
  int distance;
  int time;
  Node prev;
  ArrayList<Edge> neighbors;

  public Node( String name) {
    this.name = name;
    this.neighbors = new ArrayList<Edge>();
    this.distance = Integer.MAX_VALUE;
    this.money = Integer.MAX_VALUE;
    this.time = Integer.MAX_VALUE;
    this.prev = null;
  }

  public void addNeighbor(int distance, int time, int money, Node n) {
    neighbors.add(new Edge(distance, time, money, n));
    n.neighbors.add(new Edge(distance, time, money, this));
  }
  
  public String toString() {
    return distance + " " + time + " " + money;
  }

public int compareTo(Node other) {
		
		if(pathType == 0) {
			return Integer.compare(this.distance, other.distance);
		} else if(pathType == 1) {
			return Integer.compare(this.time, other.time);
		} else {
			return Integer.compare(this.money, other.money);
		}
		
  }

  public int testing(int a) {
   return a;
 }
  
}