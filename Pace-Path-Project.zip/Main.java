import java.util.PriorityQueue;

class Main {


  
  public static void main(String[] args) {
    
  Node a = new Node("The Met");
  Node b = new Node("Time Square");
  Node c = new Node("Museum of Natural History");
  Node d = new Node("Grand Central Station");
  Node e = new Node("Chrysler Building");
  Node f = new Node("Penn Station");
  Node g = new Node("Empire State Building");
  Node h = new Node("Flatiron Building");
  Node i = new Node("1 Pace Plaza");
  Node j = new Node("Brooklyn Bridge");
  Node k = new Node("163 William Street");
    
  a.addNeighbor(10,30,10,d);

  b.addNeighbor(2,2,2,d);
  b.addNeighbor(8,20,8,c);
  b.addNeighbor(1,4,2,g);
  b.addNeighbor(1,4,2,f);
    
  c.addNeighbor(8,20,8,b);

  d.addNeighbor(10,30,10,a);
  d.addNeighbor(1,1,1,e);
  d.addNeighbor(7,5,2,i);
  d.addNeighbor(2,2,2,b);

  e.addNeighbor(1,1,1,d);

  f.addNeighbor(1,4,2,b);
  f.addNeighbor(1,3,1,g);

  g.addNeighbor(1,4,2,b);
  g.addNeighbor(1,3,1,f);
  g.addNeighbor(2,3,2,h);

  h.addNeighbor(2,3,2,g);
  h.addNeighbor(3,5,3,k);

  i.addNeighbor(1,1,1,k);
  i.addNeighbor(1,1,1,j);
  i.addNeighbor(7,5,2,d);

  j.addNeighbor(1,1,1,i);
  j.addNeighbor(1,2,1,k);

  k.addNeighbor(1,1,1,i);
  k.addNeighbor(1,1,1,j);
  k.addNeighbor(3,5,3,h);
    
path(a, k, 0);
  
  

    
  }

  public static void path(Node start, Node end, int pathType) {

    
    PriorityQueue<Node> pq = new PriorityQueue<Node>();

    Helper help = new Helper();
    help.setPath(pathType);

    if (pathType == 0) {  
      pq.add(start);
      start.distance = 0;
    while (!pq.isEmpty()) {
      Node current = pq.poll();

      if (current == end) {
        break;
      }

      for (Edge e : current.neighbors) {
        int tempDistance = current.distance + e.distance;
        Node n = e.n;

        if (tempDistance > n.distance) {
          continue;
        }

        n.distance = tempDistance;
        n.prev = current;

        pq.remove(n);
        pq.add(n);
      }
    }
  }
    
    if (pathType == 1) {  
      pq.add(start);
       start.time = 0;
    while (!pq.isEmpty()) {
      Node current = pq.poll();

      if (current == end) {
        break;
      }

      for (Edge e : current.neighbors) {
        int tempTime = current.time + e.time;
        Node n = e.n;

        if (tempTime > n.time) {
          continue;
        }

        n.distance = tempTime;
        n.prev = current;

        pq.remove(n);
        pq.add(n);
      }
    }
  }

    if (pathType == 2) {  
      pq.add(start);
      start.money = 0;
    
    
    while (!pq.isEmpty()) {
      Node current = pq.poll();

      if (current == end) {
        break;
      }

      for (Edge e : current.neighbors) {
        int tempMoney = current.money + e.money;
        Node n = e.n;

        if (tempMoney > n.money) {
          continue;
        }

        n.distance = tempMoney;
        n.prev = current;

        pq.remove(n);
        pq.add(n);
      }
    }
  }
    printPath(end);
  }

  public static void printPath(Node n) {
    if (n == null) {
      return;
    }
  printPath(n.prev);
  System.out.println(n.name);
  }

}