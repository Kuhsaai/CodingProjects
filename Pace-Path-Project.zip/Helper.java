
public class Helper {
	
	 int pathType;
	 
	
	 public void setPath(int x) {
		 pathType = x;
	}
	

}
